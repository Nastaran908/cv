#include "ayne.h"
#include "ui_ayne.h"

ayne::ayne(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::ayne)
{
    ui->setupUi(this);
}

ayne::~ayne()
{
    delete ui;
}

void ayne::on_ayneButton_clicked()
{
    int n=ui->aynelineEdit->text().toInt();
    int num=0 , p=n , r ;
    while (n!=0) {
        r=n%10 ;
        num = num*10 + r ;
        n=n/10 ;
    }
    if (p==num)
         ui->aynelabel->setText("yes");
    else
         ui->aynelabel->setText("no");
}

