#ifndef ABS_H
#define ABS_H

#include <QMainWindow>

namespace Ui {
class abs;
}

class abs : public QMainWindow
{
    Q_OBJECT

public:
    explicit abs(QWidget *parent = nullptr);
    ~abs();

private slots:
    void on_absButton_clicked();

private:
    Ui::abs *ui;
};

#endif // ABS_H
