#include "ghadrmotlagh.h"
#include "ui_ghadrmotlagh.h"

ghadrmotlagh::ghadrmotlagh(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::ghadrmotlagh)
{
    ui->setupUi(this);
}

ghadrmotlagh::~ghadrmotlagh()
{
    delete ui;
}

void ghadrmotlagh::on_ghButton_clicked()
{
    int n=ui->ghlineEdit->text().toInt();
    int x ;
    if (n<0)
    {x = n*-1 ;
        ui->ghlabel->setText(QString::number(x));
    }
    else
        ui->ghlabel->setText(QString::number(n));
}

