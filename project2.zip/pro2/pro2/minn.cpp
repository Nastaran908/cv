#include "minn.h"
#include "ui_minn.h"

minn::minn(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::minn)
{
    ui->setupUi(this);
}

minn::~minn()
{
    delete ui;
}

void minn::on_min1Button_clicked()
{
    int n1=ui->min1lineEdit->text().toInt();
    int n2=ui->min2lineEdit->text().toInt();
    int n3=ui->min3lineEdit->text().toInt();
    int mini = n1 ;
    if (n2<mini)
        mini = n2 ;
    if (n3<mini)
        mini = n3 ;
    ui->minlabel->setText(QString::number(mini));
}

