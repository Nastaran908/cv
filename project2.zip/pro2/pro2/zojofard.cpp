#include "zojofard.h"
#include "ui_zojofard.h"

zojofard::zojofard(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::zojofard)
{
    ui->setupUi(this);
}

zojofard::~zojofard()
{
    delete ui;
}

void zojofard::on_zfButton_clicked()
{
    int n=ui->zflineEdit->text().toInt();
    if (n%2==0)
        ui->zflabel->setText("zoj");
    else
        ui->zflabel->setText("fard");
}
