#ifndef ZOJOFARD_H
#define ZOJOFARD_H

#include <QMainWindow>

namespace Ui {
class zojofard;
}

class zojofard : public QMainWindow
{
    Q_OBJECT

public:
    explicit zojofard(QWidget *parent = nullptr);
    ~zojofard();

private slots:
    void on_zfButton_clicked();

private:
    Ui::zojofard *ui;
};

#endif // ZOJOFARD_H
