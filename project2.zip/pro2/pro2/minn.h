#ifndef MINN_H
#define MINN_H

#include <QMainWindow>

namespace Ui {
class minn;
}

class minn : public QMainWindow
{
    Q_OBJECT

public:
    explicit minn(QWidget *parent = nullptr);
    ~minn();

private slots:
    void on_min1Button_clicked();

private:
    Ui::minn *ui;
};

#endif // MINN_H
