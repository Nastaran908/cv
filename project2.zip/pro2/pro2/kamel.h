#ifndef KAMEL_H
#define KAMEL_H

#include <QMainWindow>

namespace Ui {
class kamel;
}

class kamel : public QMainWindow
{
    Q_OBJECT

public:
    explicit kamel(QWidget *parent = nullptr);
    ~kamel();

private slots:
    void on_kamel1Button_clicked();

private:
    Ui::kamel *ui;
};

#endif // KAMEL_H
