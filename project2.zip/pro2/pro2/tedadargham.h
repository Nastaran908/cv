#ifndef TEDADARGHAM_H
#define TEDADARGHAM_H

#include <QMainWindow>

namespace Ui {
class tedadargham;
}

class tedadargham : public QMainWindow
{
    Q_OBJECT

public:
    explicit tedadargham(QWidget *parent = nullptr);
    ~tedadargham();

private slots:
    void on_tedadButton_clicked();

private:
    Ui::tedadargham *ui;
};

#endif // TEDADARGHAM_H
