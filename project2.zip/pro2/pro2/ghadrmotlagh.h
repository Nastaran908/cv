#ifndef GHADRMOTLAGH_H
#define GHADRMOTLAGH_H

#include <QMainWindow>

namespace Ui {
class ghadrmotlagh;
}

class ghadrmotlagh : public QMainWindow
{
    Q_OBJECT

public:
    explicit ghadrmotlagh(QWidget *parent = nullptr);
    ~ghadrmotlagh();

private slots:
    void on_ghButton_clicked();

private:
    Ui::ghadrmotlagh *ui;
};

#endif // GHADRMOTLAGH_H
