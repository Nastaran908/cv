#ifndef AYNE_H
#define AYNE_H

#include <QMainWindow>

namespace Ui {
class ayne;
}

class ayne : public QMainWindow
{
    Q_OBJECT

public:
    explicit ayne(QWidget *parent = nullptr);
    ~ayne();

private slots:
    void on_ayneButton_clicked();

private:
    Ui::ayne *ui;
};

#endif // AYNE_H
