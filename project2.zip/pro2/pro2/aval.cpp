#include "aval.h"
#include "ui_aval.h"

aval::aval(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::aval)
{
    ui->setupUi(this);
}

aval::~aval()
{
    delete ui;
}

void aval::on_aval1Button_clicked()
{
    int n=ui->avallineEdit->text().toInt();
    int i,f=0;
    for(i=1;i<=n;i++)
    {if(n%i==0)
        f++;}
    if(f==2)
        ui->avallabel->setText("yes");
    else
        ui->avallabel->setText("no");
}

