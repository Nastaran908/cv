#include "kamel.h"
#include "ui_kamel.h"

kamel::kamel(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::kamel)
{
    ui->setupUi(this);
}

kamel::~kamel()
{
    delete ui;
}

void kamel::on_kamel1Button_clicked()
{
     int n=ui->kamellineEdit->text().toInt();
    int sum=0 , i=1 ;
     while (i<n)
    {if(n%i==0)
             sum+=i ;
         i++ ;}
     if (sum==n)
         ui->kamellabel->setText("yes");
     else
         ui->kamellabel->setText("no");
}

