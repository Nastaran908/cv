#include "fact.h"
#include "ui_fact.h"

fact::fact(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::fact)
{
    ui->setupUi(this);
}

fact::~fact()
{
    delete ui;
}

void fact::on_factButton_clicked()
{
    int n=ui->factlineEdit->text().toInt();
    int f=1 , i ;
    for (i=1 ; i<=n ; i++)
        f*=i ;
     ui->factlabel->setText(QString::number(f));
}

