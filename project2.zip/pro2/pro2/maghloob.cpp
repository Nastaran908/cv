#include "maghloob.h"
#include "ui_maghloob.h"

maghloob::maghloob(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::maghloob)
{
    ui->setupUi(this);
}

maghloob::~maghloob()
{
    delete ui;
}

void maghloob::on_maghoolButton_clicked()
{
    int n=ui->maghlooblineEdit->text().toInt();
    int a , b , c ;
    a = n/10 ;
    b = n%10 ;
    b *= 10 ;
    c = b+a ;
    ui->maghlooblabel->setText(QString::number(c));
}

