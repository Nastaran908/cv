#include "area.h"
#include "ui_area.h"

area::area(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::area)
{
    ui->setupUi(this);
}

area::~area()
{
    delete ui;
}

void area::on_area1Button_clicked()
{
    float n=ui->arealineEdit->text().toFloat();
    float s;
    s = 4*3.14*n*n ;
    ui->arealabel->setText(QString::number(s));
}

