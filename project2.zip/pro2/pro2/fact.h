#ifndef FACT_H
#define FACT_H

#include <QMainWindow>

namespace Ui {
class fact;
}

class fact : public QMainWindow
{
    Q_OBJECT

public:
    explicit fact(QWidget *parent = nullptr);
    ~fact();

private slots:
    void on_factButton_clicked();

private:
    Ui::fact *ui;
};

#endif // FACT_H
