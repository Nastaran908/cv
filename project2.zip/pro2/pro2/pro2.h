#ifndef PRO2_H
#define PRO2_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui {
class pro2;
}
QT_END_NAMESPACE

class pro2 : public QMainWindow
{
    Q_OBJECT

public:
    pro2(QWidget *parent = nullptr);
    ~pro2();

private slots:
    void on_avalButton_clicked();

    void on_kamelButton_clicked();

    void on_areaButton_clicked();

    void on_maghloobButton_clicked();


    void on_absButton_clicked();

    void on_zojofardButton_clicked();

    void on_numberButton_clicked();

    void on_minButton_clicked();

    void on_ayneButton_clicked();

    void on_factButton_clicked();

private:
    Ui::pro2 *ui;
};
#endif // PRO2_H
