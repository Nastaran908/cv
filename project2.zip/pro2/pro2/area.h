#ifndef AREA_H
#define AREA_H

#include <QMainWindow>

namespace Ui {
class area;
}

class area : public QMainWindow
{
    Q_OBJECT

public:
    explicit area(QWidget *parent = nullptr);
    ~area();

private slots:
    void on_area1Button_clicked();

private:
    Ui::area *ui;
};

#endif // AREA_H
