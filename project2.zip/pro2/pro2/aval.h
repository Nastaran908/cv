#ifndef AVAL_H
#define AVAL_H

#include <QMainWindow>

namespace Ui {
class aval;
}

class aval : public QMainWindow
{
    Q_OBJECT

public:
    explicit aval(QWidget *parent = nullptr);
    ~aval();

private slots:
    void on_aval1Button_clicked();

private:
    Ui::aval *ui;
};

#endif // AVAL_H
