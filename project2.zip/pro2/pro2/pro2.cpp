#include "pro2.h"
#include "ui_pro2.h"
#include "aval.h"
#include "kamel.h"
#include "area.h"
#include "maghloob.h"
#include "ghadrmotlagh.h"
#include "zojofard.h"
#include "tedadargham.h"
#include "minn.h"
#include "ayne.h"
#include "fact.h"

pro2::pro2(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::pro2)
{
    ui->setupUi(this);
}

pro2::~pro2()
{
    delete ui;
}

void pro2::on_avalButton_clicked()
{
    aval *a = new aval;
    a->show();
    hide();
}


void pro2::on_kamelButton_clicked()
{
    kamel *k = new kamel;
    k->show();
    hide();

}


void pro2::on_areaButton_clicked()
{
    area *r = new area;
    r->show();
    hide();
}

void pro2::on_maghloobButton_clicked()
{
    maghloob *m = new maghloob;
    m->show();
    hide();
}

void pro2::on_absButton_clicked()
{
    ghadrmotlagh *g = new ghadrmotlagh;
    g->show();
    hide();
}


void pro2::on_zojofardButton_clicked()
{
    zojofard *z = new zojofard;
    z->show();
    hide();
}


void pro2::on_numberButton_clicked()
{
    tedadargham *t = new tedadargham;
    t->show();
    hide();
}


void pro2::on_minButton_clicked()
{
    minn *m = new minn;
    m->show();
    hide();
}


void pro2::on_ayneButton_clicked()
{
    ayne *y = new ayne;
    y->show();
    hide();

}


void pro2::on_factButton_clicked()
{
    fact *f = new fact;
    f->show();
    hide();

}

