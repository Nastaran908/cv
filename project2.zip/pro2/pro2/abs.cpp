#include "abs.h"
#include "ui_abs.h"

abs::abs(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::abs)
{
    ui->setupUi(this);
}

abs::~abs()
{
    delete ui;
}

void abs::on_absButton_clicked()
{
    int n=ui->abslineEdit->text().toInt();
    int x;
    if (n<0)
    {x=n*-1;
        ui->abslabel->setText(QString::number(x));}
    else
         ui->abslabel->setText(QString::number(n));
}

