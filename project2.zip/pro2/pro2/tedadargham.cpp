#include "tedadargham.h"
#include "ui_tedadargham.h"

tedadargham::tedadargham(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::tedadargham)
{
    ui->setupUi(this);
}

tedadargham::~tedadargham()
{
    delete ui;
}

void tedadargham::on_tedadButton_clicked()
{
    int n=ui->tedadlineEdit->text().toInt();
    int c=0 , r ;
    while(n!=0)
    {   r=n%10 ;
        n=n/10 ;
        c++ ;}
    ui->tedadlabel->setText(QString::number(c));
}
