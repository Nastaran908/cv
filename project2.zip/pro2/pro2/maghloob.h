#ifndef MAGHLOOB_H
#define MAGHLOOB_H

#include <QMainWindow>

namespace Ui {
class maghloob;
}

class maghloob : public QMainWindow
{
    Q_OBJECT

public:
    explicit maghloob(QWidget *parent = nullptr);
    ~maghloob();

private slots:
    void on_maghoolButton_clicked();

private:
    Ui::maghloob *ui;
};

#endif // MAGHLOOB_H
